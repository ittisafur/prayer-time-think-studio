<template>
  <div class="flex justify-between py-5 mx-auto wrapper">
    <h1>Prayer Times</h1>
    <div class="flex space-x-5">
      <NuxtLink class="nav-link active" to="/">Home</NuxtLink>
      <NuxtLink class="nav-link" to="/calendar">Calendar</NuxtLink>
    </div>
  </div>
</template>
