<template>
  <div class="font-nunito">
    <Header />
    <Nuxt />
  </div>
</template>
