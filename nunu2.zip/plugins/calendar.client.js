import Vue from "vue";

import "vue-simple-calendar/static/css/default.css";
import { CalendarView } from "vue-simple-calendar";

Vue.component("v-calender", CalendarView);
