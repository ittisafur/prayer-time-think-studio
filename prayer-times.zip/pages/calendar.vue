<template>
  <div>
    <client-only>
      <calendar-view
        :show-date="showDate"
        :items="events"
        class="theme-default holiday-us-traditional holiday-us-official"
      />
    </client-only>
  </div>
</template>

<script>
export default {
  name: "calendar",
  date() {
    return {
      showDate: new Date(),
      events: [],
    };
  },
  async mounted() {
    await this.$axios
      .$get("https://api.aladhan.com/v1/gToHCalendar/5/2021")
      .then((res) => {
        this.events = this.formatDatesForCalender(res.data.data);
      });
  },
  methods: {
    formatDatesForCalender(dates) {
      return dates.map((date) => {
        const year = date.gregorian.date.split("-")[2];
        const month = date.gregorian.date.split("-")[1];
        const day = date.gregorian.date.split("-")[0];

        const hday = date.hijri.date.split("-")[0]; //?
        const hmonthName = date.hijri.month.en; //?

        const formated = {
          id: date.gregorian.date,
          startDate: `${year}-${month}-${day}`,
          title: `${hday} ${hmonthName}`,
        };
        return formated;
      });
    },
  },
};
</script>
