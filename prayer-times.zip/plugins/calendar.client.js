import Vue from "vue"
import "vue-simple-calendar/static/css/default.css";
// import "vue-simple-calendar/static/css/holidays-us.css"
import {CalendarView} from "vue-simple-calendar";

Vue.use(CalendarView, CalendarView)
