<template>
  <div>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <Header />
        </div>
      </div>
    </div>
    <Nuxt />
  </div>
</template>

