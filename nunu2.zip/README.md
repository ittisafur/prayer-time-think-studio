# prayer-time

## Setup

```bash
# install dependencies
$ yarn install
# serve with hot reload at localhost:3000
$ yarn dev

```

TODOS

- [x] Render today's prayer time in Dhaka
- [ ] Work on getting the location ( A bit was done with the vanilla js experiment using navigator.geolocation.getCurrentPosition() ). We can use it with the api to pin point the location and get the country and other details
- [x] Months, Years and Method ( Which source is used to render the time ex  University of Islamic Sciences, Karachi) is being used
